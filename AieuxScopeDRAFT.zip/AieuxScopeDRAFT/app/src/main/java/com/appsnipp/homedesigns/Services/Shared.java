package com.appsnipp.homedesigns.Services;

import static android.service.controls.ControlsProviderService.TAG;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;

import com.appsnipp.homedesigns.Models.Result;
import com.appsnipp.homedesigns.Models.User;
import com.appsnipp.homedesigns.ProfileActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Shared {
    public static String token="";
    public static  void login(Context context,String email, String password){
        APIServices service =   RetrofitAPI.getRetrofitInstance().create(APIServices.class);
        User user = new User(email,password);
        Call<Result> call = service.login(user);
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                try{

                    switch (response.body().getResult()){
                        case "error":{
                            Shared.Alert(context,"Error !","An Error was occurred try later ");
                            return;
                        }
                        case "not" : {
                            Shared.Alert(context,"Error !","the email or password selected is incorrect");
                            return;
                        }
                        default:
                            DatabaseHelper databaseHelper = new DatabaseHelper(context);
                            databaseHelper.deleteUser();
                            databaseHelper.addUser(user);
                            Shared.token = response.body().getResult();
                            Intent intent = new Intent(context, ProfileActivity.class);
                            context.startActivity(intent);
                    }
                }catch (Exception e){
                    Shared.Alert(context,"Error !","An Error was occurred try later ");
                    Log.e(TAG,"onFailure: "+ e.getMessage());
                }
            }
            @Override
            public void onFailure(Call<Result> call, Throwable t) {
                Shared.Alert(context,"Error !","An Error was occurred try later ");
                Log.e(TAG,"onFailure: "+ t.getMessage());
            }
        });
    }
    public static void Alert(Context context, String Title, String Body){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(Title)
                .setMessage(Body)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {}
                }).show();
    }
}
