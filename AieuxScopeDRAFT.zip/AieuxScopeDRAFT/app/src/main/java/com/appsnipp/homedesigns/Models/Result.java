package com.appsnipp.homedesigns.Models;

public class Result {
    String result;
    String id;

    public Result(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
